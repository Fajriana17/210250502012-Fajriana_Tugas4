

package UkuranBaju;


public class if_kondisi3 {
     public static void main(String[] args) {
        
        int ukuran ;
        
        ukuran= 51;
        
        if(ukuran <=46){
            System.out.println("ukuran S");
        } else if (ukuran <=48) {
            System.out.println("ukuran M");
        } else if ( ukuran <=50){
            System.out.println("ukuran L");
        } else{ 
            System.out.println("ukuran XL");
        }
            
    }
}
