

package UkuranBaju;


public class if_kondisi2 {
    public static void main(String[] args) {
        
        int ukuran;
        
        ukuran=49;
        
        if(ukuran <=46){
            System.out.println("ukuran S");
        } else if (ukuran <=48) {
            System.out.println("ukuran M");
        } else {
            System.out.println("ukuran L");
        }
            
    }
}
