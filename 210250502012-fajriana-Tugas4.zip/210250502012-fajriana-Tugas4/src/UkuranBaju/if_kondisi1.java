


package UkuranBaju;




public class if_kondisi1 {
    public static void main(String[] args) {
        int ukuran; 
        ukuran= 45 ;
        
        if(ukuran <=46){
            System.out.println("ukuran S");
        } else {
            System.out.println("ukuran M");
        }
    }
}
